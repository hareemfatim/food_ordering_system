from tkinter import *
import mysql.connector
import datetime
from tkinter import Tk,StringVar, ttk
import tkinter.messagebox as tmsg


db = mysql.connector.connect(host ="localhost",user = 'root',password = '',db ='info')


     

root=Tk()
root.title("Food ordering System")

now = datetime.datetime.now()

time=now.strftime("%Y-%m-%d %X")
address=StringVar()
mobile=StringVar()
name=StringVar()
email=StringVar()

def disp():
    n=name.get()
    a=email.get()
    add=address.get()
    mob=mobile.get()
   
  
    if (address.get()=="") :
        tmsg.showinfo("Error","Please enter address where food is delivered ")
    elif mobile.get()=="":
        tmsg.showinfo("Error","Please enter mobile number")
   
    else:
        cursor = db.cursor()
        cursor.execute('''INSERT INTO `infomation`( `name`, `email`,`address`,`mobile`) VALUES (%s,%s,%s,%s,%s)''', (n,a , add,mob ))
        # mysql.connection.commit()
        cursor.execute("commit")
        cursor.close()
        final=tmsg.showinfo("Info",f"""Hello! {name.get()} Your name {address.get()} correct address
        Thank you for information!""")



Label(root,text="Name",font="arial 11 bold",bg="white").grid(row=4,column=6,sticky="w")
Entry(root,textvariable=name,width=30,justify="left").grid(row=5,column=6,sticky="w")

#adding email number
Label(root,text="Email",font="arial 11 bold",bg="white").grid(row=7,column=6,sticky="w")
Entry(root,textvariable=email,width=30,justify="left").grid(row=8,column=6,sticky="w")


#adding address
Label(root,text="Address",font="arial 11 bold",bg="white").grid(row=10,column=6,sticky="w")
Entry(root,textvariable=address,width=50,justify="left").grid(row=11,column=6,sticky="w")

#adding mobile number
Label(root,text="Mobile Number",font="arial 11 bold",bg="white").grid(row=13,column=6,sticky="w")
Entry(root,textvariable=mobile,width=30,justify="left").grid(row=14,column=6,sticky="w")


Button(root,text="    submit    ",font="Arial 10 bold",borderwidth=3,relief=RAISED,command=disp,bg="red",fg="white").grid(row=17,column=4)


root.mainloop()